g++ -std=c++11 -flto -march=native -mtune=knl -O3 bayesnet.cpp -o code
chmod 777 run.sh